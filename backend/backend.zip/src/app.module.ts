import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { Module } from '@nestjs/common';
import { CatalogoModule } from './catalogo/catalogo.module'; // <-- Importar esto

@Module({
  imports: [CatalogoModule], // <-- Agregar esto aquí
  controllers: [],
  providers: [],
})
export class AppModule {}

@Module({
  imports: [],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
