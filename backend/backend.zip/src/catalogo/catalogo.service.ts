import { Injectable } from '@nestjs/common';
// @ts-ignore
import * as pdf from 'pdf-parse';

@Injectable()
export class CatalogoService {
  async procesarPdf(buffer: Buffer): Promise<any[]> {
    try {
      // Usamos la librería para extraer el texto crudo
      const data = await pdf(buffer);
      const lineas = data.text.split('\n');
      const resultados: any[] = [];

      lineas.forEach((linea: string) => {
        // Buscamos líneas que tengan el formato del proveedor con "$"
        if (linea.includes('$')) {
          const limpia = linea.replace(/"/g, '').trim();
          const partes = limpia.split(',');

          if (partes.length >= 2) {
            const nombreRaw = partes[0].trim();
            const precioRaw = partes[1].trim();
            const costo = parseFloat(precioRaw.replace(/[$. ,]/g, ''));

            if (!isNaN(costo) && costo > 0) {
              resultados.push({
                nombre: nombreRaw,
                costo: costo,
              });
            }
          }
        }
      });
      return resultados;
    } catch (error) {
      console.error('Error procesando PDF:', error);
      throw new Error('No se pudo procesar el archivo PDF');
    }
  }
}